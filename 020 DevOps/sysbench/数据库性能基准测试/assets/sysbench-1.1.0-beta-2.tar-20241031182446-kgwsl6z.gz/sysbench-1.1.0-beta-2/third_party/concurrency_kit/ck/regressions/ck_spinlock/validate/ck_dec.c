#include "../ck_dec.h"
#include "validate.h"
