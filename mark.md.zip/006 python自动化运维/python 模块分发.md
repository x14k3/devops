# python 模块分发

主要介绍包(模块)的分发，也就是如何将你的包打包，然后分发给别人使用。
在这之前你需要了解：
[python pip](python%20pip.md)：pip & wheel
