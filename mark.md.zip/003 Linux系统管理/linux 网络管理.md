# linux 网络管理

对于Linux来说，现在流行的有网络管理有两个工具，Network服务与NetworkManager  
前者做为基础服务，桌面版和服务器中都有，后者，即NetworkManager，一般只在桌面版中安装，因为其有图形配置界面，也深受用户欢迎。  
需要注意的是，这两个网络配置，只能有一个生效，而不能同时生效。

* 📄 [linux bridge](siyuan://blocks/20230803173114-w9zlqes)
* 📄 [linux NetworkManager](siyuan://blocks/20230803163647-p2txceg)
* 📄 [linux 聚合链路](siyuan://blocks/20230610173719-r7o6gsh)
* 📄 [linux 路由管理](siyuan://blocks/20230610173807-kqlwuyg)
* 📄 [linux 网络配置](siyuan://blocks/20230803163800-ql9cifl)

‍

‍
