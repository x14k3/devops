# linux 进程管理

‍

* 📄 [linux supervisord](siyuan://blocks/20230731184946-hlebj0x)
* 📄 [linux systemd](siyuan://blocks/20230610173754-nolls1s)

‍

‍
