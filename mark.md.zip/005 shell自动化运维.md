# 005 shell自动化运维

* 📄 [shell 脚本格式化输出](siyuan://blocks/20230610173741-sn1v2zl)
* 📄 [shell 脚本命令](siyuan://blocks/20230610173745-hfsmeq4)
* 📑 [shell 脚本收集](siyuan://blocks/20230610173811-iop1c5j)

  * 📄 [jar包服务启动停止shell脚本](siyuan://blocks/20230728160057-biltend)
  * 📄 [mysql数据库备份脚本](siyuan://blocks/20230728160319-wyoy2i9)
  * 📄 [pyhton-nacos配置文件转义](siyuan://blocks/20230728160247-78g4isw)
  * 📄 [Shell内部将输出显示在屏幕并同时写入文件](siyuan://blocks/20230728160339-y5rep6h)
  * 📄 [ssh免密批量处理](siyuan://blocks/20230728160358-fi2vf0k)
  * 📄 [zabbix监控端口数据（自动发现规则）](siyuan://blocks/20230728160138-fopxr18)
  * 📄 [服务器初始化脚本](siyuan://blocks/20230728160229-njxw1nw)
  * 📄 [文件转发utf-8](siyuan://blocks/20230728160303-g7q1q33)
  * 📄 [志压缩清理](siyuan://blocks/20230728160118-68cbsxw)
* 📄 [shell 命令手册](siyuan://blocks/20230610171821-54vnv1p)
* 📄 [shell 三剑客](siyuan://blocks/20230610173713-fn6aj6j)
* 📄 [shell 数组详解](siyuan://blocks/20230610173709-rak6m93)
* 📄 [正则表达式](siyuan://blocks/20230610173733-1p8ps8r)

‍
