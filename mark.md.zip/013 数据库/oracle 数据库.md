# oracle 数据库

* 📄 [Oracle CDB PDB](siyuan://blocks/20230610173723-08oclj0)
* 📄 [Oracle DataGuard](siyuan://blocks/20230610173547-1zw1vzn)
* 📄 [Oracle GoldenGate](siyuan://blocks/20230610173808-hl38w6a)
* 📄 [Oracle OMF](siyuan://blocks/20230610173718-bphnylg)
* 📄 [Oracle RAC](siyuan://blocks/20230610173750-5626gvb)
* 📄 [Oracle 常见操作](siyuan://blocks/20230610173758-pj3584i)
* 📄 [Oracle 常见问题处理](siyuan://blocks/20230610173743-i6ajaw6)
* 📄 [Oracle 内存管理](siyuan://blocks/20230610173728-92xuq8c)
* 📄 [Oracle 日志归档](siyuan://blocks/20230610173719-y490nhz)
* 📄 [Oracle 数据泵](siyuan://blocks/20230610173756-hosoprr)
* 📄 [Oracle 数据恢复](siyuan://blocks/20230610173811-s336emd)
* 📄 [Oracle 数据异机恢复](siyuan://blocks/20230610173747-do0gmu0)
* 📄 [Oracle 体系结构](siyuan://blocks/20230615095446-m624kr7)
* 📄 [Oracle 优化 &amp; 安全配置](siyuan://blocks/20230610173806-5k3psgk)
* 📄 [Oracle19c 静默安装](siyuan://blocks/20230610173719-49ku7zv)
* 📄 [RMAN 备份策略](siyuan://blocks/20230610173656-6zpszm6)

‍
