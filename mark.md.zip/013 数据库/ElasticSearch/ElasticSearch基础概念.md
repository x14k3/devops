# ElasticSearch基础概念

‍
