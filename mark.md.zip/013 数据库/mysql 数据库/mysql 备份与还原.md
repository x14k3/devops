# mysql 备份与还原

‍

* 📄 [1. mysqldump 逻辑备份](siyuan://blocks/20230808135803-lchlxmd)
* 📄 [2. xtrabackup 物理备份](siyuan://blocks/20230808140703-lgcwbsp)
* 📄 [3. mysqlbinlog实现全量恢复](siyuan://blocks/20230808164704-ubhta9w)

‍
