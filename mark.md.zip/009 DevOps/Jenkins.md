# Jenkins

* 📄 [Jenkins 命令](siyuan://blocks/20230610173806-y2du2h3)
* 📄 [Jenkins 部署](siyuan://blocks/20230610173748-b3zi8o0)

‍
