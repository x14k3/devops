# Jenkins 命令

‍
