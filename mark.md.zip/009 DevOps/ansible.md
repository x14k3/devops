# ansible

* 📄 [Ansible-role](siyuan://blocks/20230610173739-datbx4q)
* 📄 [Ansible-playbook](siyuan://blocks/20230610173713-tdao649)
* 📄 [Ansible](siyuan://blocks/20230610173658-8gi2xbx)

‍
