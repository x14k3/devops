# 006 python自动化运维

* 📄 [python pip](siyuan://blocks/20230610173719-juolnbe)
* 📄 [python 定义函数](siyuan://blocks/20230610173437-cxwfzby)
* 📄 [python 基础语法](siyuan://blocks/20230610173751-w8se6ik)
* 📑 [python 模块](siyuan://blocks/20230610173811-7ejnj1c)

  * 📄 [open](siyuan://blocks/20230610173618-eiw0cjz)
  * 📄 [psutil](siyuan://blocks/20230610173612-y6ud1tv)
* 📄 [python 模块分发](siyuan://blocks/20230610173809-fmy3ite)
* 📄 [Python2 &amp; Python3](siyuan://blocks/20230610173647-eswkkwm)

‍
