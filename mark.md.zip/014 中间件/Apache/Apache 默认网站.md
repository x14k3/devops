# Apache 默认网站

## 一、默认网站

每一个web服务器软件一般默认都会提供一个用于测试的网站，apache也为用户提供了一个默认网站。默认网站的配置写在默认配置文件中。

## 二、配置文件

[root@zutuanxue conf]# cat httpd.conf

```
#

# This is the main Apache HTTP server configuration file. It contains the

# configuration directives that give the server its instructions.

# See (URL:http://httpd.apache.org/docs/2.4/); for detailed information.

# In particular, see

# URL:http://httpd.apache.org/docs/2.4/mod/directives.html;

# for a discussion of each configuration directive.

#

# Do NOT simply read the instructions in here without understanding

# what they do. They're here only as hints or reminders. If you are unsure

# consult the online docs. You have been warned.

#

# Configuration and logfile names: If the filenames you specify for many

# of the server's control files begin with "/" (or "drive:/" for Win32), the

# server will use that explicit path. If the filenames do *not* begin

# with "/", the value of ServerRoot is prepended -- so "logs/access_log"

# with ServerRoot set to "/usr/local/apache2" will be interpreted by the

# server as "/usr/local/apache2/logs/access_log", whereas "/logs/access_log"

# will be interpreted as '/logs/access_log'.

#

# ServerRoot: The top of the directory tree under which the server's

# configuration, error, and log files are kept.

#

# Do not add a slash at the end of the directory path. If you point

# ServerRoot at a non-local disk, be sure to specify a local disk on the

# Mutex directive, if file-based mutexes are used. If you wish to share the

# same ServerRoot for multiple httpd daemons, you will need to change at

# least PidFile.

#

#apache软件根目录，apache安装路径。

ServerRoot "/usr/local/apache"

#

# Mutex: Allows you to set the mutex mechanism and mutex file directory

# for individual mutexes, or change the global defaults

#

# Uncomment and change the directory if mutexes are file-based and the default

# mutex file directory is not on a local disk or is not appropriate for some

# other reason.

#

# Mutex default:logs

#

# Listen: Allows you to bind Apache to specific IP addresses and/or

# ports, instead of the default. See also the &lt;VirtualHost&gt;

# directive.

#

# Change this to Listen on specific IP addresses as shown below to

# prevent Apache from glomming onto all bound IP addresses.

#

#设置apache监听端口及监听IP地址

#Listen 12.34.56.78:80

Listen 80

#

# Dynamic Shared Object (DSO) Support

#

# To be able to use the functionality of a module which was built as a DSO you

# have to place corresponding `LoadModule' lines at this location so the

# directives contained in it are actually available _before_ they are used.

# Statically compiled modules (those listed by `httpd -l') do not need

# to be loaded here.

#

# 动态共享对象支持,使用LoadModule指令为apaceh添加功能模块  --enable-so

# Example:

# LoadModule foo_module modules/mod_foo.so

#

# 可载入模块，参考(http://httpd.apache.org/docs/2.4/mod/)

LoadModule mpm_event_module modules/mod_mpm_event.so

#LoadModule mpm_prefork_module modules/mod_mpm_prefork.so

#LoadModule mpm_worker_module modules/mod_mpm_worker.so

LoadModule authn_file_module modules/mod_authn_file.so

#LoadModule authn_dbm_module modules/mod_authn_dbm.so

#LoadModule authn_anon_module modules/mod_authn_anon.so

#LoadModule authn_dbd_module modules/mod_authn_dbd.so

#LoadModule authn_socache_module modules/mod_authn_socache.so

LoadModule authn_core_module modules/mod_authn_core.so

LoadModule authz_host_module modules/mod_authz_host.so

LoadModule authz_groupfile_module modules/mod_authz_groupfile.so

LoadModule authz_user_module modules/mod_authz_user.so

#LoadModule authz_dbm_module modules/mod_authz_dbm.so

#LoadModule authz_owner_module modules/mod_authz_owner.so

#LoadModule authz_dbd_module modules/mod_authz_dbd.so

LoadModule authz_core_module modules/mod_authz_core.so

LoadModule access_compat_module modules/mod_access_compat.so

LoadModule auth_basic_module modules/mod_auth_basic.so

#LoadModule auth_form_module modules/mod_auth_form.so

#LoadModule auth_digest_module modules/mod_auth_digest.so

#LoadModule allowmethods_module modules/mod_allowmethods.so

#LoadModule file_cache_module modules/mod_file_cache.so

#LoadModule cache_module modules/mod_cache.so

#LoadModule cache_disk_module modules/mod_cache_disk.so

#LoadModule cache_socache_module modules/mod_cache_socache.so

#LoadModule socache_shmcb_module modules/mod_socache_shmcb.so

#LoadModule socache_dbm_module modules/mod_socache_dbm.so

#LoadModule socache_memcache_module modules/mod_socache_memcache.so

#LoadModule socache_redis_module modules/mod_socache_redis.so

#LoadModule watchdog_module modules/mod_watchdog.so

#LoadModule macro_module modules/mod_macro.so

#LoadModule dbd_module modules/mod_dbd.so

#LoadModule dumpio_module modules/mod_dumpio.so

#LoadModule buffer_module modules/mod_buffer.so

#LoadModule ratelimit_module modules/mod_ratelimit.so

LoadModule reqtimeout_module modules/mod_reqtimeout.so

#LoadModule ext_filter_module modules/mod_ext_filter.so

#LoadModule request_module modules/mod_request.so

#LoadModule include_module modules/mod_include.so

LoadModule filter_module modules/mod_filter.so

#LoadModule substitute_module modules/mod_substitute.so

#LoadModule sed_module modules/mod_sed.so

#LoadModule deflate_module modules/mod_deflate.so

LoadModule mime_module modules/mod_mime.so

LoadModule log_config_module modules/mod_log_config.so

#LoadModule log_debug_module modules/mod_log_debug.so

#LoadModule logio_module modules/mod_logio.so

LoadModule env_module modules/mod_env.so

#LoadModule expires_module modules/mod_expires.so

LoadModule headers_module modules/mod_headers.so

#LoadModule unique_id_module modules/mod_unique_id.so

LoadModule setenvif_module modules/mod_setenvif.so

LoadModule version_module modules/mod_version.so

#LoadModule remoteip_module modules/mod_remoteip.so

#LoadModule proxy_module modules/mod_proxy.so

#LoadModule proxy_connect_module modules/mod_proxy_connect.so

#LoadModule proxy_ftp_module modules/mod_proxy_ftp.so

#LoadModule proxy\_http_module modules/mod_proxy_http.so

#LoadModule proxy_fcgi_module modules/mod_proxy_fcgi.so

#LoadModule proxy_scgi_module modules/mod_proxy_scgi.so

#LoadModule proxy_uwsgi_module modules/mod_proxy_uwsgi.so

#LoadModule proxy_fdpass_module modules/mod_proxy_fdpass.so

#LoadModule proxy_wstunnel_module modules/mod_proxy_wstunnel.so

#LoadModule proxy_ajp_module modules/mod_proxy_ajp.so

#LoadModule proxy_balancer_module modules/mod_proxy_balancer.so

#LoadModule proxy_express_module modules/mod_proxy_express.so

#LoadModule proxy_hcheck_module modules/mod_proxy_hcheck.so

#LoadModule session_module modules/mod_session.so

#LoadModule session_cookie_module modules/mod_session_cookie.so

#LoadModule session_dbd_module modules/mod_session_dbd.so

#LoadModule slotmem_shm_module modules/mod_slotmem_shm.so

#LoadModule lbmethod_byrequests_module modules/mod_lbmethod_byrequests.so

#LoadModule lbmethod_bytraffic_module modules/mod_lbmethod_bytraffic.so

#LoadModule lbmethod_bybusyness_module modules/mod_lbmethod_bybusyness.so

#LoadModule lbmethod_heartbeat_module modules/mod_lbmethod_heartbeat.so

LoadModule unixd_module modules/mod_unixd.so

#LoadModule dav_module modules/mod_dav.so

LoadModule status_module modules/mod_status.so

LoadModule autoindex_module modules/mod_autoindex.so

#LoadModule info_module modules/mod_info.so

#LoadModule cgid_module modules/mod_cgid.so

#LoadModule dav_fs_module modules/mod_dav_fs.so

#LoadModule vhost_alias_module modules/mod_vhost_alias.so

#LoadModule negotiation_module modules/mod_negotiation.so

LoadModule dir_module modules/mod_dir.so

#LoadModule actions_module modules/mod_actions.so

#LoadModule speling_module modules/mod_speling.so

LoadModule alias_module modules/mod_alias.so

#LoadModule rewrite_module modules/mod_rewrite.so

#启用模块 unixd_module 设置apache守护进程httpd的管理用户和组

#启用模块注意格式 <IfModule 模块名称_module>

#结束</IfModule>

#启用的前提是已经使用LoadModule指令载入了该模块

<IfModule unixd\_module>

#

# If you wish httpd to run as a different user or group, you must run

# httpd as root initially and it will switch.

#

# User/Group: The name (or #number) of the user/group to run httpd as.

# It is usually good practice to create a dedicated user and group for

# running httpd, as with most system services.

#

#指定守护进程httpd的管理用户

User daemon

#指定守护进程httpd的管理组

Group daemon

</IfModule>

# 'Main' server configuration

#

# The directives in this section set up the values used by the 'main'

# server, which responds to any requests that aren't handled by a

# &lt;VirtualHost&gt; definition. These values also provide defaults for

# any &lt;VirtualHost&gt; containers you may define later in the file.

#

# All of these directives may appear inside &lt;VirtualHost&gt; containers,

# in which case these default settings will be overridden for the

# virtual host being defined.

#

#

# ServerAdmin: Your address, where problems with the server should be

# e-mailed. This address appears on some server-generated pages, such

# as error documents. e.g. admin@your-domain.com

#

#指定管理员email地址

ServerAdmin you@example.com

#

# ServerName gives the name and port that the server uses to identify itself.

# This can often be determined automatically, but we recommend you specify

# it explicitly to prevent problems during startup.

#

# If your host doesn't have a registered DNS name, enter its IP address here.

#

#指定服务器在DNS上注册的名称  FQDN

#ServerName www.example.com:80

ServerName 127.0.0.1

#

# Deny access to the entirety of your server's filesystem. You must

# explicitly permit access to web content directories in other

# &lt;Directory&gt; blocks below.

#

#apache 目录访问权限

#使用<Directory /path> 指定目录路径

#拒绝用户通过apache访问你的文件系统/及以下的所有内容

<Directory >

#是否允许.htaccess实现权限复写

AllowOverride none

#设置所有人的访问权限  denied 拒绝  granted允许

Require all denied

#设置结束用</Directory>指令结束

</Directory>

#

# Note that from this point forward you must specifically allow

# particular features to be enabled - so if something's not working as

# you might expect, make sure that you have specifically enabled it

# below.

#

#

# DocumentRoot: The directory out of which you will serve your

# documents. By default, all requests are taken from this directory, but

# symbolic links and aliases may be used to point to other locations.

#

#使用DocumentRoot指定WEB站点的根目录

DocumentRoot "/usr/local/apache/htdocs"

#对默认网站根目录设置访问权限

<Directory "/usr/local/apache/htdocs">

#

# Possible values for the Options directive are "None", "All",

# or any combination of:

#  Indexes Includes FollowSymLinks SymLinksifOwnerMatch ExecCGI MultiViews

#

# Note that "MultiViews" must be named *explicitly* --- "Options All"

# doesn't give it to you.

#

# The Options directive is both complicated and important. Please see

# (http://httpd.apache.org/docs/2.4/mod/core.html#options)

# for more information.

#

Options Indexes FollowSymLinks

#Indexes 站点中有index页面优先加载

#FollowSymLinks  在WEB站点根目录允许使用链接文件

#

# AllowOverride controls what directives may be placed in .htaccess files.

# It can be "All", "None", or any combination of the keywords:

#  AllowOverride FileInfo AuthConfig Limit

#

#不许使用权限复写

AllowOverride None

#

# Controls who can get stuff from this server.

#

#允许所有人访问网站根目录

Require all granted

</Directory>

#

# DirectoryIndex: sets the file that Apache will serve if a directory

# is requested.

#指定站点的默认索引文件

<IfModule dir\_module>

DirectoryIndex index.html

</IfModule>

#

# The following lines prevent .htaccess and .htpasswd files from being

# viewed by Web clients.

#

#是否允许在目录下使用.htaccess 和 .htpassswd文件设置客户端对网站目录访问权限

#.htaccess 访问控制

#.htpasswd 用户登陆验证

#拒绝在目录下使用.ht开头的文件

<Files ".ht\*">

Require all denied

</Files>

#

# ErrorLog: The location of the error log file.

# If you do not specify an ErrorLog directive within a <VirtualHost>

# container, error messages relating to that virtual host will be

# logged here. If you *do* define an error logfile for a <VirtualHost>

# container, that host's errors will be logged there and not here.

#

#错误日志

ErrorLog "logs/error_log"

#

# LogLevel: Control the number of messages logged to the error\_log.

# Possible values include: debug, info, notice, warn, error, crit,

# alert, emerg.

#

#错误日志记录级别:debug, info, notice, warn, error, crit,alert, emerg.

LogLevel warn

#启用日志模块

<IfModule log\_config\_module>

#

# The following directives define some format nicknames for use with

# a CustomLog directive (see below).

#

#定义日志格式  LogFormat  "日志格式"  日志格式名称

LogFormat "%h %l %u %t \"%r\" %&gt;s %b \"%{Referer}i\" \"%{User-Agent}i\"" combined

LogFormat "%h %l %u %t \"%r\" %&gt;s %b" common

<IfModule logio\_module>

# 在访问日志中记录每个请求的输入输出字节 %I input  %O output

# You need to enable mod\_logio.c to use %I and %O

LogFormat "%h %l %u %t \"%r\" %&gt;s %b \"%{Referer}i\" \"%{User-Agent}i\" %I %O" combinedio

</IfModule>

#

# The location and format of the access logfile (Common Logfile Format).

# If you do not define any access logfiles within a &lt;VirtualHost&gt;

# container, they will be logged here. Contrariwise, if you *do*

# define per-<VirtualHost> access logfiles, transactions will be

# logged therein and \*not\* in this file.

#

#定义访问日志路径及日志格式

CustomLog "logs/access_log" common

#

# If you prefer a logfile with access, agent, and referer information

# (Combined Logfile Format) you can use the following directive.

#

#CustomLog "logs/access_log" combined

</IfModule>

#使用目录映射

<IfModule alias\_module>

#

# URL重定向

# Redirect: Allows you to tell clients about documents that used to

# exist in your server's namespace, but do not anymore. The client

# will make a new request for the document at its new location.

# Example:

# Redirect permanent /foo http://www.example.com/bar

#URL重定向  Redirect 方法  选项

#不同机器重定向将访问http://IP/abc 的用户 重定向访问 http:/www.baidu.com

Redirect permanent /abc http://www.baidu.com

#本机内部URL重定向 http://IP/123 http://IP/7878 ==注意==：被重定向的目录必须存在 比如7878必须有

Redirect permanent /123 /7878

#seeother 表示改资源被替换过

Redirect seeother /123 /7878

#gone 表示改资源被移除了

Redirect gone /123

#permanent 永久重定向 301

#temp  临时重定向

#seeother 返回一个seeother状态码(303)提示这个资源被替代

#gone 返回一个gone状态码(410)提示这个资源被永久删除了

#

# Alias: Maps web paths into filesystem paths and is used to

# access content that does not live under the DocumentRoot.

# Example:

# Alias /webpath /full/filesystem/path

#

# If you include a trailing / on /webpath then the server will

# require it to be present in the URL. You will also likely

# need to provide a <Directory> section to allow access to

# the filesystem path.

#Alias 将URI中的没用了映射到文件系统目录(绝对路径)

#比如将网站URL http://ip/abc 访问的/abc目录映射到文件系统/usr/local/apache/htdocs/7878

Alias /abc /usr/local/apache/htdocs/7878

#需要注意是文件系统路径

#

# ScriptAlias: This controls which directories contain server scripts.

# ScriptAliases are essentially the same as Aliases, except that

# documents in the target directory are treated as applications and

# run by the server when requested rather than as documents sent to the

# client. The same rules about trailing "/" apply to ScriptAlias

# directives as to Alias.

#

ScriptAlias /cgi-bin/ "/usr/local/apache/cgi-bin/"

#脚本目录别名

</IfModule>

#使用外部CGI守护进程执行CGI脚本

<IfModule cgid_module>

#

# ScriptSock: On threaded servers, designate the path to the UNIX

# socket used to communicate with the CGI daemon of mod\_cgid.

#

#Scriptsock cgisock

</IfModule>

#

# "/usr/local/apache/cgi-bin" should be changed to whatever your ScriptAliased

# CGI directory exists, if you have that configured.

#

#CGI目录的访问权限

<Directory "/usr/local/apache/cgi-bin">

AllowOverride None

Options None

Require all granted

</Directory>

#自定义http的请求头和响应头

#RequestHeader 设置请求头 http://httpd.apache.org/docs/2.4/mod/mod_headers.html

#Header 设置响应头 http://httpd.apache.org/docs/2.4/mod/mod_headers.html

<IfModule headers\_module>

#

# Avoid passing HTTP\_PROXY environment to CGI's on this or any proxied

# backend servers which have lingering "httpoxy" defects.

# 'Proxy' request header is undefined by the IETF, not listed by IANA

#

RequestHeader unset Proxy early

</IfModule>

#将请求的文件扩展名与文件的行为（处理程序和筛选器）和内容（mime类型、语言、字符集和编码）相关联。

#明确告诉apache 可以接受什么类型的文件

<IfModule mime_module>

#

# TypesConfig points to the file containing the list of mappings from

# filename extension to MIME-type.

#

TypesConfig conf/mime.types

#

# AddType allows you to add to or override the MIME configuration

# file specified in TypesConfig for specific file types.

#

#AddType application/x-gzip .tgz

#

# AddEncoding allows you to have certain browsers uncompress

# information on the fly. Note: Not all browsers support this.

#

#AddEncoding x-compress .Z

#AddEncoding x-gzip .gz .tgz

#

# If the AddEncoding directives above are commented-out, then you

# probably should define those extensions to indicate media types:

#

AddType application/x-compress .Z

AddType application/x-gzip .gz .tgz

#

# AddHandler allows you to map certain file extensions to "handlers":

# actions unrelated to filetype. These can be either built into the server

# or added with the Action directive (see below)

#

# To use CGI scripts outside of ScriptAliased directories:

# (You will also need to add "ExecCGI" to the "Options" directive.)

#

#AddHandler cgi-script .cgi

# For type maps \(negotiated resources\):

#AddHandler type-map var

#

# Filters allow you to process content before it is sent to the client.

#

# To parse .shtml files for server-side includes (SSI):

# (You will also need to add "Includes" to the "Options" directive.)

#

#AddType text/html .shtml

#AddOutputFilter INCLUDES .shtml

</IfModule>

#

# The mod_mime_magic module allows the server to use various hints from the

# contents of the file itself to determine its type. The MIMEMagicFile

# directive tells the module where the hint definitions are located.

#

#MIMEMagicFile conf/magic

#

# Customizable error responses come in three flavors:

# 1) plain text 2) local redirects 3) external redirects

#

# Some examples:

#ErrorDocument 500 "The server made a boo boo."

#ErrorDocument 404 /missing.html

#ErrorDocument 404 "/cgi-bin/missing\_handler.pl"

#ErrorDocument 402 [http://www.example.com/subscription\_info.html](http://www.example.com/subscription_info.html)

#

#

# MaxRanges: Maximum number of Ranges in a request before

# returning the entire resource, or one of the special

# values 'default', 'none' or 'unlimited'.

# Default setting is to accept 200 Ranges.

#MaxRanges unlimited

#

# EnableMMAP and EnableSendfile: On systems that support it,

# memory-mapping or the sendfile syscall may be used to deliver

# files. This usually improves server performance, but must

# be turned off when serving from networked-mounted

# filesystems or if support for these functions is otherwise

# broken on your system.

# Defaults: EnableMMAP On, EnableSendfile Off

#

#EnableMMAP off

#EnableSendfile on

# Supplemental configuration

#

# The configuration files in the conf/extra/ directory can be

# included to add extra features or to modify the default configuration of

# the server, or you may simply copy their contents here and change as

# necessary.

#Include 包含子配置文件

# Server-pool management \(MPM specific\)

#Include conf/extra/httpd-mpm.conf

# Multi-language error messages

#Include conf/extra/httpd-multilang-errordoc.conf

# Fancy directory listings

#Include conf/extra/httpd-autoindex.conf

# Language settings

#Include conf/extra/httpd-languages.conf

# User home directories

#Include conf/extra/httpd-userdir.conf

# Real-time info on requests and configuration

#Include conf/extra/httpd-info.conf

# Virtual hosts

#Include conf/extra/httpd-vhosts.conf

# Local access to the Apache HTTP Server Manual

#Include conf/extra/httpd-manual.conf

# Distributed authoring and versioning (WebDAV)

#Include conf/extra/httpd-dav.conf

# Various default settings

#Include conf/extra/httpd-default.conf

# Configure mod_proxy_html to understand HTML4/XHTML1

#启动代理模块

<IfModule proxy\_html_module>

Include conf/extra/proxy-html.conf

</IfModule>;

# Secure (SSL/TLS) connections

#Include conf/extra/httpd-ssl.conf

#

# Note: The following must must be present to support

#  starting without SSL on platforms with no /dev/random equivalent

#  but a statically compiled-in mod\_ssl.

#

#启用ssl模块

<IfModule ssl_module>

SSLRandomSeed startup builtin

SSLRandomSeed connect builtin

</IfModule>;
```
