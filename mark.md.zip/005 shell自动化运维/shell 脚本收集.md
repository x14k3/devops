# shell 脚本收集

* 📄 [jar包服务启动停止shell脚本](siyuan://blocks/20230728160057-biltend)
* 📄 [zabbix监控端口数据（自动发现规则）](siyuan://blocks/20230728160138-fopxr18)
* 📄 [常用脚本收集](siyuan://blocks/20230610173752-avf91sn)
* 📄 [志压缩清理](siyuan://blocks/20230728160118-68cbsxw)

‍
