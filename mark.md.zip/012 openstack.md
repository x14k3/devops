# 012 openstack

* 📄 [1.openstack 概述](siyuan://blocks/20230610173725-56rjmgb)
* 📄 [2.Openstack使用](siyuan://blocks/20230610173803-vo4uq7d)
* 📑 [openstack部署](siyuan://blocks/20230610173810-4ucs1m6)

  * 📄 [1.基础环境部署](siyuan://blocks/20230610173749-vlb9wuk)
  * 📄 [10.启动实例](siyuan://blocks/20230610173745-1tiotup)
  * 📄 [11.Swift 部署](siyuan://blocks/20230610173549-xpmyxhp)
  * 📄 [12.Manila部署-未完成](siyuan://blocks/20230610173806-p7u8y6w)
  * 📄 [13.Trove部署-未完成](siyuan://blocks/20230610173805-h313vd4)
  * 📄 [14.Heat部署-未完成](siyuan://blocks/20230610173806-7e36s0y)
  * 📄 [15.Ceilometer部署-未完成](siyuan://blocks/20230610173806-ccbkp3p)
  * 📄 [2.依赖中间件部署](siyuan://blocks/20230610173735-au9mmat)
  * 📄 [3.Keystone部署](siyuan://blocks/20230610173729-d827cs2)
  * 📄 [4.Glance部署](siyuan://blocks/20230610173750-pufpqn0)
  * 📄 [5.Placement部署](siyuan://blocks/20230610173746-0gb34zu)
  * 📄 [6.Nova部署](siyuan://blocks/20230610173735-2lhu8ox)
  * 📄 [7.Neutron部署](siyuan://blocks/20230610173714-yc3dcj5)
  * 📄 [8.Horizone部署](siyuan://blocks/20230610173756-oct988t)
  * 📄 [9.Cinder部署](siyuan://blocks/20230610173733-418utcb)
* 📑 [openstack组件](siyuan://blocks/20230610173810-g9goz8n)

  * 📄 [OpenStack之Cinder组件详解](siyuan://blocks/20230610173645-np3nh4k)
  * 📄 [OpenStack之Glance组件详解](siyuan://blocks/20230610173657-nzg08om)
  * 📄 [OpenStack之Keystone组件详解](siyuan://blocks/20230610173745-hbzhoxy)
  * 📄 [OpenStack之Neutron组件详解](siyuan://blocks/20230610173429-va8kuma)
  * 📄 [OpenStack之Nova组件详解](siyuan://blocks/20230610173631-dze77qw)
  * 📄 [OpenStack之Placement组件详解](siyuan://blocks/20230610173738-zkrsssm)

‍
