# openstack部署

* 📄 [12.Manila部署-未完成](siyuan://blocks/20230610173806-p7u8y6w)
* 📄 [15.Ceilometer部署-未完成](siyuan://blocks/20230610173806-ccbkp3p)
* 📄 [14.Heat部署-未完成](siyuan://blocks/20230610173806-7e36s0y)
* 📄 [13.Trove部署-未完成](siyuan://blocks/20230610173805-h313vd4)
* 📄 [8.Horizone部署](siyuan://blocks/20230610173756-oct988t)
* 📄 [4.Glance部署](siyuan://blocks/20230610173750-pufpqn0)
* 📄 [1.基础环境部署](siyuan://blocks/20230610173749-vlb9wuk)
* 📄 [5.Placement部署](siyuan://blocks/20230610173746-0gb34zu)
* 📄 [10.启动实例](siyuan://blocks/20230610173745-1tiotup)
* 📄 [2.依赖中间件部署](siyuan://blocks/20230610173735-au9mmat)
* 📄 [6.Nova部署](siyuan://blocks/20230610173735-2lhu8ox)
* 📄 [9.Cinder部署](siyuan://blocks/20230610173733-418utcb)
* 📄 [3.Keystone部署](siyuan://blocks/20230610173729-d827cs2)
* 📄 [7.Neutron部署](siyuan://blocks/20230610173714-yc3dcj5)
* 📄 [11.Swift 部署](siyuan://blocks/20230610173549-xpmyxhp)

‍
